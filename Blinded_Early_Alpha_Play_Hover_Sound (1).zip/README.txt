
Blinded - Early Alpha Build

Includes:
- First-person movement
- Toggleable flashlight
- Partial map (school)
- Early monster logic
- ESC menu placeholder
- Day/Night basics
- Sprint/stamina (WIP)

To play:
Open 'index.html' in a browser. This is a placeholder. The final HTML5 build with graphics and logic is in progress.
